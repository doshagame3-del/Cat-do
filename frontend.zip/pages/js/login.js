'use strict';

(() => {
  const form = document.getElementById('login-form');
  const submitBtn = document.getElementById('submit-btn');
  const alertBox = document.getElementById('alert');

  function showAlert(message, type = 'error') {
    alertBox.textContent = message;
    alertBox.className = `alert ${type}`;
    alertBox.style.display = 'block';
  }

  function clearFieldErrors() {
    document.querySelectorAll('.field-error').forEach((el) => {
      el.textContent = '';
    });
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    alertBox.style.display = 'none';
    clearFieldErrors();

    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const password = document.getElementById('password').value;

    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in…';

    try {
      await TalkPulseAPI.login({ phoneNumber, password });
      window.location.href = 'dashboard.html';
    } catch (err) {
      if (err.code === 'NETWORK_ERROR') {
        showAlert('Unable to reach the server. Please check your connection and try again.');
      } else if (err.code === 'ACCOUNT_LOCKED') {
        showAlert('Account temporarily locked due to repeated failed attempts. Try again later.');
      } else if (err.code === 'INVALID_CREDENTIALS') {
        showAlert('Incorrect phone number or password.');
      } else if (err.code === 'RATE_LIMITED') {
        showAlert('Too many attempts. Please wait a bit before trying again.');
      } else {
        showAlert(err.message || 'Something went wrong. Please try again.');
      }
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Log in';
    }
  });
})();
