'use strict';

(() => {
  const dashboardCard = document.getElementById('dashboard-card');
  const loadingCard = document.getElementById('loading-card');
  const errorCard = document.getElementById('error-card');
  const dashboardError = document.getElementById('dashboard-error');

  function showError(message) {
    loadingCard.style.display = 'none';
    dashboardCard.style.display = 'none';
    dashboardError.textContent = message;
    errorCard.style.display = 'block';
  }

  async function bootstrap() {
    errorCard.style.display = 'none';
    loadingCard.style.display = 'block';

    // The access token lives only in memory, so a fresh page load
    // (no token yet) always needs a silent refresh using the
    // httpOnly cookie before it can call a protected endpoint.
    if (!TalkPulseAPI.getAccessToken()) {
      try {
        const ok = await TalkPulseAPI.refresh();
        if (!ok) {
          window.location.href = 'login.html';
          return;
        }
      } catch (err) {
        if (err.code === 'NETWORK_ERROR') {
          showError('Unable to reach the server. Please check your connection and try again.');
          return;
        }
        window.location.href = 'login.html';
        return;
      }
    }

    try {
      const user = await TalkPulseAPI.getMe();
      renderUser(user);
    } catch (err) {
      if (err.code === 'NETWORK_ERROR') {
        showError('Unable to reach the server. Please check your connection and try again.');
      } else {
        window.location.href = 'login.html';
      }
    }
  }

  function renderUser(user) {
    const name = user.displayName || user.phoneNumber;
    document.getElementById('avatar-initial').textContent = name.charAt(0).toUpperCase();
    document.getElementById('display-name').textContent = name;
    document.getElementById('phone-number').textContent = user.phoneNumber;

    loadingCard.style.display = 'none';
    dashboardCard.style.display = 'block';
  }

  document.getElementById('logout-btn').addEventListener('click', async () => {
    await TalkPulseAPI.logout();
    window.location.href = 'login.html';
  });

  document.getElementById('retry-btn').addEventListener('click', bootstrap);

  bootstrap();
})();
