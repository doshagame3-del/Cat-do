'use strict';

(() => {
  const form = document.getElementById('signup-form');
  const submitBtn = document.getElementById('submit-btn');
  const alertBox = document.getElementById('alert');

  function showAlert(message, type = 'error') {
    alertBox.textContent = message;
    alertBox.className = `alert ${type}`;
    alertBox.style.display = 'block';
  }

  function clearFieldErrors() {
    document.querySelectorAll('.field-error').forEach((el) => {
      el.textContent = '';
    });
  }

  function applyFieldErrors(details = []) {
    details.forEach((d) => {
      const el = document.getElementById(`${d.field}-error`);
      if (el) el.textContent = d.message;
    });
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    alertBox.style.display = 'none';
    clearFieldErrors();

    const displayName = document.getElementById('displayName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const password = document.getElementById('password').value;

    if (!phoneNumber) {
      applyFieldErrors([{ field: 'phoneNumber', message: 'Phone number is required' }]);
      return;
    }
    if (password.length < 8) {
      applyFieldErrors([{ field: 'password', message: 'Password must be at least 8 characters' }]);
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Creating account…';

    try {
      await TalkPulseAPI.signup({ phoneNumber, password, displayName: displayName || undefined });
      showAlert('Account created! Redirecting…', 'success');
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 600);
    } catch (err) {
      if (err.code === 'VALIDATION_ERROR' && err.details) {
        applyFieldErrors(err.details);
      } else if (err.code === 'PHONE_TAKEN') {
        showAlert('An account with this phone number already exists.');
      } else if (err.code === 'RATE_LIMITED') {
        showAlert('Too many attempts. Please wait a bit before trying again.');
      } else {
        showAlert(err.message || 'Something went wrong. Please try again.');
      }
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Create account';
    }
  });
})();
