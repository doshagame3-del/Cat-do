'use strict';

(() => {
  const dashboardCard = document.getElementById('dashboard-card');
  const loadingCard = document.getElementById('loading-card');

  async function bootstrap() {
    // The access token lives only in memory, so a fresh page load
    // (no token yet) always needs a silent refresh using the
    // httpOnly cookie before it can call a protected endpoint.
    if (!TalkPulseAPI.getAccessToken()) {
      const ok = await TalkPulseAPI.refresh();
      if (!ok) {
        window.location.href = 'login.html';
        return;
      }
    }

    try {
      const user = await TalkPulseAPI.getMe();
      renderUser(user);
    } catch {
      window.location.href = 'login.html';
    }
  }

  function renderUser(user) {
    const name = user.displayName || user.phoneNumber;
    document.getElementById('avatar-initial').textContent = name.charAt(0).toUpperCase();
    document.getElementById('display-name').textContent = name;
    document.getElementById('phone-number').textContent = user.phoneNumber;

    loadingCard.style.display = 'none';
    dashboardCard.style.display = 'block';
  }

  document.getElementById('logout-btn').addEventListener('click', async () => {
    await TalkPulseAPI.logout();
    window.location.href = 'login.html';
  });

  bootstrap();
})();
