'use strict';

/**
 * Minimal API client for the TalkPulse auth module.
 * - Keeps the access token in memory only (never localStorage), to
 *   limit exposure to XSS-based token theft.
 * - Sends credentials so the httpOnly refresh-token cookie is included.
 * - Transparently retries a request once after a silent token refresh
 *   if the access token has expired.
 */
const TalkPulseAPI = (() => {
  const BASE_URL = 'http://localhost:5000/api/v1/auth';

  let accessToken = null;

  function setAccessToken(token) {
    accessToken = token;
  }

  function getAccessToken() {
    return accessToken;
  }

  async function request(path, { method = 'GET', body, retry = true } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (accessToken) {
      headers.Authorization = `Bearer ${accessToken}`;
    }

    const response = await fetch(`${BASE_URL}${path}`, {
      method,
      headers,
      credentials: 'include', // send/receive the httpOnly refresh cookie
      body: body ? JSON.stringify(body) : undefined,
    });

    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }

    if (response.status === 401 && payload?.code === 'TOKEN_EXPIRED' && retry) {
      const refreshed = await refresh();
      if (refreshed) {
        return request(path, { method, body, retry: false });
      }
    }

    if (!response.ok) {
      const error = new Error(payload?.message || 'Request failed');
      error.status = response.status;
      error.code = payload?.code;
      error.details = payload?.details;
      throw error;
    }

    return payload;
  }

  async function signup({ phoneNumber, password, displayName }) {
    const res = await request('/signup', {
      method: 'POST',
      body: { phoneNumber, password, displayName },
    });
    setAccessToken(res.data.accessToken);
    return res.data.user;
  }

  async function login({ phoneNumber, password }) {
    const res = await request('/login', {
      method: 'POST',
      body: { phoneNumber, password },
    });
    setAccessToken(res.data.accessToken);
    return res.data.user;
  }

  async function refresh() {
    try {
      const res = await request('/refresh', { method: 'POST', retry: false });
      setAccessToken(res.data.accessToken);
      return true;
    } catch {
      setAccessToken(null);
      return false;
    }
  }

  async function logout() {
    await request('/logout', { method: 'POST', retry: false }).catch(() => {});
    setAccessToken(null);
  }

  async function getMe() {
    const res = await request('/me', { method: 'GET' });
    return res.data.user;
  }

  return { signup, login, refresh, logout, getMe, getAccessToken, setAccessToken };
})();
