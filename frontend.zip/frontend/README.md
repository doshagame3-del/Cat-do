# TalkPulse — Auth Module (Frontend)

Plain HTML/CSS/JS — no build step required. Talks to the backend at
`http://localhost:5000` (edit `BASE_URL` in `js/api.js` if yours differs).

## Run

Serve the folder with any static file server (opening via `file://` will
break cookies/CORS). The simplest options:

```bash
# from the frontend/ folder
npx serve -l 5500
# or
python3 -m http.server 5500
```

Then visit `http://localhost:5500/pages/login.html` (or `/pages/signup.html`).

Make sure the backend's `CLIENT_ORIGIN` in `.env` matches this origin
exactly (e.g. `http://localhost:5500`), since the refresh-token cookie is
sent cross-origin with `credentials: 'include'` and requires an exact CORS
match — `*` will not work with credentials.

## Pages

- `pages/signup.html` — create an account
- `pages/login.html` — log in
- `pages/dashboard.html` — protected page; redirects to login if there's no
  valid session (does a silent token refresh first via the httpOnly cookie)

## Notes

- The access token is kept in memory only (`js/api.js`), so it's lost on
  page reload — `dashboard.js` calls `/auth/refresh` on load to get a new
  one from the refresh cookie automatically.
