'use strict';

const User = require('../models/User');
const AppError = require('../utils/AppError');
const catchAsync = require('../utils/catchAsync');
const env = require('../config/env');
const {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  hashToken,
} = require('../utils/tokens');

const REFRESH_COOKIE_NAME = 'tp_refresh_token';

const refreshCookieOptions = Object.freeze({
  httpOnly: true,
  secure: env.isProduction, // requires HTTPS in production
  // 'strict'/'lax' block the cookie whenever the frontend is on a
  // different origin than the backend (e.g. two separate Vercel
  // projects) since that's a cross-site request from the browser's
  // point of view. 'none' is required for cross-site cookies, and is
  // only safe combined with secure:true (already set above).
  sameSite: env.isProduction ? 'none' : 'lax',
  path: '/api/v1/auth', // only sent to auth endpoints
  maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days, kept in sync with JWT_REFRESH_EXPIRES_IN default
});

async function issueSession(res, user) {
  const accessToken = signAccessToken(user._id.toString());
  const refreshToken = signRefreshToken(user._id.toString());

  user.refreshTokenHash = hashToken(refreshToken);
  await user.save();

  res.cookie(REFRESH_COOKIE_NAME, refreshToken, refreshCookieOptions);
  return accessToken;
}

/**
 * POST /api/v1/auth/signup
 * Creates a new account from a normalized phone number + password.
 */
const signup = catchAsync(async (req, res, next) => {
  const { phoneNumber, password, displayName } = req.body;

  const existing = await User.findOne({ phoneNumber });
  if (existing) {
    return next(new AppError('An account with this phone number already exists', 409, 'PHONE_TAKEN'));
  }

  const user = new User({ phoneNumber, displayName });
  await user.setPassword(password);
  await user.save();

  const accessToken = await issueSession(res, user);

  return res.status(201).json({
    status: 'success',
    data: {
      user: user.toPublicJSON(),
      accessToken,
    },
  });
});

/**
 * POST /api/v1/auth/login
 * Authenticates a user and issues a new access/refresh token pair.
 * Applies account lockout after repeated failed attempts.
 */
const login = catchAsync(async (req, res, next) => {
  const { phoneNumber, password } = req.body;

  const user = await User.findOne({ phoneNumber }).select(
    '+passwordHash +failedLoginAttempts +lockUntil'
  );

  // Use an identical error message/status for "no such user" and "bad
  // password" so the endpoint can't be used to enumerate registered
  // phone numbers.
  const invalidCredsError = () =>
    new AppError('Invalid phone number or password', 401, 'INVALID_CREDENTIALS');

  if (!user) {
    return next(invalidCredsError());
  }

  if (user.isLocked) {
    return next(
      new AppError(
        'Account temporarily locked due to repeated failed login attempts. Try again later.',
        423,
        'ACCOUNT_LOCKED'
      )
    );
  }

  const passwordMatches = await user.comparePassword(password);
  if (!passwordMatches) {
    await user.registerFailedLogin();
    return next(invalidCredsError());
  }

  await user.registerSuccessfulLogin();
  const accessToken = await issueSession(res, user);

  return res.status(200).json({
    status: 'success',
    data: {
      user: user.toPublicJSON(),
      accessToken,
    },
  });
});

/**
 * POST /api/v1/auth/refresh
 * Rotates the refresh token (reads it from the httpOnly cookie) and
 * issues a new access token. Rejects reuse of an already-rotated token.
 */
const refresh = catchAsync(async (req, res, next) => {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];
  if (!token) {
    return next(new AppError('Missing refresh token', 401, 'NO_REFRESH_TOKEN'));
  }

  let payload;
  try {
    payload = verifyRefreshToken(token);
  } catch {
    res.clearCookie(REFRESH_COOKIE_NAME, refreshCookieOptions);
    return next(new AppError('Invalid or expired refresh token', 401, 'INVALID_REFRESH_TOKEN'));
  }

  const user = await User.findById(payload.sub).select('+refreshTokenHash');
  if (!user || user.refreshTokenHash !== hashToken(token)) {
    // Token was already rotated or the user no longer exists — treat
    // as a potential replay and force re-authentication.
    res.clearCookie(REFRESH_COOKIE_NAME, refreshCookieOptions);
    return next(new AppError('Refresh token is no longer valid', 401, 'REFRESH_TOKEN_REVOKED'));
  }

  const accessToken = await issueSession(res, user);

  return res.status(200).json({
    status: 'success',
    data: { accessToken },
  });
});

/**
 * POST /api/v1/auth/logout
 * Invalidates the current refresh token server-side and clears the cookie.
 */
const logout = catchAsync(async (req, res) => {
  const token = req.cookies?.[REFRESH_COOKIE_NAME];

  if (token) {
    try {
      const payload = verifyRefreshToken(token);
      await User.findByIdAndUpdate(payload.sub, {
        refreshTokenHash: null,
        isOnline: false,
        lastSeenAt: new Date(),
      });
    } catch {
      // Token already invalid/expired — nothing to revoke, proceed to clear cookie.
    }
  }

  res.clearCookie(REFRESH_COOKIE_NAME, refreshCookieOptions);
  return res.status(200).json({ status: 'success', data: null });
});

/**
 * GET /api/v1/auth/me
 * Returns the profile of the currently authenticated user.
 * Requires the `protect` middleware to have run first.
 */
const getMe = catchAsync(async (req, res) => {
  return res.status(200).json({
    status: 'success',
    data: { user: req.user.toPublicJSON() },
  });
});

module.exports = { signup, login, refresh, logout, getMe, REFRESH_COOKIE_NAME, refreshCookieOptions };
