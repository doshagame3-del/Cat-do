# TalkPulse — Auth Module (Backend)

Node.js + Express + MongoDB (Mongoose) authentication service: phone number
+ password signup/login, JWT access tokens, rotating refresh tokens in an
httpOnly cookie, account lockout, and rate limiting.

## Prerequisites

- Node.js 18+
- A running MongoDB instance (local install, Docker, or Atlas)

## Setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env: set MONGO_URI and generate strong random values for
# JWT_ACCESS_SECRET / JWT_REFRESH_SECRET, e.g.:
#   node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

If you don't have MongoDB running locally, the quickest option is Docker:

```bash
docker run -d --name talkpulse-mongo -p 27017:27017 mongo:7
```

## Run

```bash
npm run dev     # with nodemon, auto-restart on change
# or
npm start
```

The server starts on `http://localhost:5000` (configurable via `PORT`).
Check it's up:

```bash
curl http://localhost:5000/health
```

## API

All routes are prefixed with `/api/v1/auth`.

| Method | Path       | Auth required | Description                              |
|--------|------------|----------------|-------------------------------------------|
| POST   | /signup    | No             | Create account: `{ phoneNumber, password, displayName? }` |
| POST   | /login     | No             | Log in: `{ phoneNumber, password }`       |
| POST   | /refresh   | Refresh cookie | Rotate refresh token, issue new access token |
| POST   | /logout    | No             | Revoke refresh token, clear cookie        |
| GET    | /me        | Bearer token   | Return the authenticated user's profile   |

`phoneNumber` accepts common formats (e.g. `+1 415 555 2671`, `(415) 555-2671`)
and is normalized to E.164 server-side. Default parsing region is US unless
a `region` (ISO 3166-1 alpha-2) field is included in the request body.

`password` must be 8–128 characters with at least one uppercase letter, one
lowercase letter, and one digit.

### Example

```bash
curl -X POST http://localhost:5000/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -c cookies.txt \
  -d '{"phoneNumber":"+14155552671","password":"Passw0rd!","displayName":"Alex"}'

curl http://localhost:5000/api/v1/auth/me \
  -H "Authorization: Bearer <accessToken from the signup response>"
```

## Security notes

- Passwords are hashed with bcrypt (cost factor from `BCRYPT_SALT_ROUNDS`, default 12).
- Access tokens are short-lived (15m default) and expected to live only in
  browser memory (never localStorage).
- Refresh tokens are long-lived (30d default), delivered as an `httpOnly`,
  `SameSite` cookie scoped to `/api/v1/auth`, and rotated on every use; only
  a SHA-256 hash of the current refresh token is stored server-side.
- 5 consecutive failed logins locks the account for 15 minutes.
- `/signup`, `/login`, `/refresh` are rate-limited per IP (20 requests /
  15 min by default).
- Helmet, CORS (locked to `CLIENT_ORIGIN`), Mongo query sanitization, and
  HTTP parameter pollution protection are all enabled by default.

## Project structure

```
backend/
  src/
    config/       env loading + validation, MongoDB connection
    controllers/  route handlers (auth business logic)
    middleware/   validation, auth guard, rate limiting, error handler
    models/       Mongoose schemas
    routes/       Express routers
    utils/        JWT helpers, AppError, async wrapper, logger
    validators/   express-validator chains
    app.js        Express app wiring
    server.js     process entry point, graceful shutdown
```
