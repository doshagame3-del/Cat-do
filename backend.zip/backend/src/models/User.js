'use strict';

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const env = require('../config/env');

const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

const userSchema = new mongoose.Schema(
  {
    phoneNumber: {
      type: String,
      required: [true, 'Phone number is required'],
      unique: true,
      trim: true,
      // Stored in E.164 format, e.g. +14155552671 — validated/normalized
      // in the controller layer via libphonenumber-js before save.
      match: [/^\+[1-9]\d{7,14}$/, 'Phone number must be a valid E.164 number'],
      index: true,
    },
    displayName: {
      type: String,
      trim: true,
      maxlength: [50, 'Display name must be at most 50 characters'],
      default: function defaultDisplayName() {
        return this.phoneNumber;
      },
    },
    passwordHash: {
      type: String,
      required: true,
      select: false, // never returned by default queries
    },
    // Hash of the currently-valid refresh token (rotated on each use).
    // Storing a hash (not the raw token) limits damage from a DB leak.
    refreshTokenHash: {
      type: String,
      select: false,
      default: null,
    },
    isOnline: {
      type: Boolean,
      default: false,
    },
    lastSeenAt: {
      type: Date,
      default: null,
    },
    failedLoginAttempts: {
      type: Number,
      default: 0,
      select: false,
    },
    lockUntil: {
      type: Date,
      default: null,
      select: false,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

userSchema.virtual('isLocked').get(function isLocked() {
  return Boolean(this.lockUntil && this.lockUntil.getTime() > Date.now());
});

userSchema.methods.setPassword = async function setPassword(plainPassword) {
  this.passwordHash = await bcrypt.hash(plainPassword, env.bcryptSaltRounds);
};

userSchema.methods.comparePassword = async function comparePassword(plainPassword) {
  return bcrypt.compare(plainPassword, this.passwordHash);
};

userSchema.methods.registerFailedLogin = async function registerFailedLogin() {
  // Reset the counter if the previous lock window has already expired.
  if (this.lockUntil && this.lockUntil.getTime() < Date.now()) {
    this.failedLoginAttempts = 0;
    this.lockUntil = null;
  }

  this.failedLoginAttempts += 1;

  if (this.failedLoginAttempts >= MAX_LOGIN_ATTEMPTS) {
    this.lockUntil = new Date(Date.now() + LOCK_WINDOW_MS);
  }

  await this.save();
};

userSchema.methods.registerSuccessfulLogin = async function registerSuccessfulLogin() {
  this.failedLoginAttempts = 0;
  this.lockUntil = null;
  this.isOnline = true;
  this.lastSeenAt = new Date();
  await this.save();
};

userSchema.methods.toPublicJSON = function toPublicJSON() {
  return {
    id: this._id.toString(),
    phoneNumber: this.phoneNumber,
    displayName: this.displayName,
    isOnline: this.isOnline,
    lastSeenAt: this.lastSeenAt,
    createdAt: this.createdAt,
  };
};

module.exports = mongoose.model('User', userSchema);
