'use strict';

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const morgan = require('morgan');

const env = require('./config/env');
const logger = require('./utils/logger');
const authRoutes = require('./routes/authRoutes');
const AppError = require('./utils/AppError');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Trust the first proxy hop (needed for correct req.ip behind a load
// balancer / reverse proxy, which the rate limiter relies on).
app.set('trust proxy', 1);

app.use(helmet());
app.use(
  cors({
    origin: env.clientOrigin,
    credentials: true, // allow the refresh-token cookie to be sent
  })
);
app.use(express.json({ limit: '10kb' })); // small limit: this endpoint only accepts short JSON payloads
app.use(cookieParser());
app.use(mongoSanitize()); // strips keys starting with '$' or containing '.' to prevent NoSQL injection
app.use(hpp()); // guards against HTTP parameter pollution

app.use(
  morgan(env.isProduction ? 'combined' : 'dev', {
    stream: { write: (message) => logger.info(message.trim()) },
  })
);

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime() });
});

app.use('/api/v1/auth', authRoutes);

// Unmatched routes
app.all('*', (req, res, next) => {
  next(new AppError(`Route not found: ${req.originalUrl}`, 404, 'NOT_FOUND'));
});

app.use(errorHandler);

module.exports = app;
