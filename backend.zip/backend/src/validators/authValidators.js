'use strict';

const { body } = require('express-validator');
const { parsePhoneNumberFromString } = require('libphonenumber-js');

/**
 * Custom validator that accepts any internationally-formatted phone
 * number (e.g. "+1 415 555 2671" or "(415) 555-2671" with a default
 * region) and normalizes it to strict E.164 for storage/lookup.
 * Mutates req.body.phoneNumber to the normalized value on success.
 */
function phoneNumberField() {
  return body('phoneNumber')
    .exists({ checkFalsy: true })
    .withMessage('Phone number is required')
    .bail()
    .isString()
    .trim()
    .customSanitizer((value) => value.replace(/[\s\-().]/g, ''))
    .custom((value, { req }) => {
      const parsed = parsePhoneNumberFromString(value, req.body.region || 'US');
      if (!parsed || !parsed.isValid()) {
        throw new Error('Phone number is not a valid phone number');
      }
      req.body.phoneNumber = parsed.number; // normalized E.164
      return true;
    });
}

const passwordRules = body('password')
  .isString()
  .isLength({ min: 8, max: 128 })
  .withMessage('Password must be between 8 and 128 characters')
  .matches(/[a-z]/)
  .withMessage('Password must contain a lowercase letter')
  .matches(/[A-Z]/)
  .withMessage('Password must contain an uppercase letter')
  .matches(/[0-9]/)
  .withMessage('Password must contain a digit');

const signupValidators = [
  phoneNumberField(),
  passwordRules,
  body('displayName')
    .optional({ checkFalsy: true })
    .isString()
    .trim()
    .isLength({ max: 50 })
    .withMessage('Display name must be at most 50 characters')
    .escape(),
];

const loginValidators = [
  phoneNumberField(),
  body('password').isString().notEmpty().withMessage('Password is required'),
];

const refreshValidators = [
  body('refreshToken').optional().isString(),
];

module.exports = { signupValidators, loginValidators, refreshValidators };
