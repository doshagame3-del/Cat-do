'use strict';

const express = require('express');
const authController = require('../controllers/authController');
const validate = require('../middleware/validate');
const protect = require('../middleware/protect');
const { authLimiter } = require('../middleware/rateLimiters');
const {
  signupValidators,
  loginValidators,
  refreshValidators,
} = require('../validators/authValidators');

const router = express.Router();

router.post('/signup', authLimiter, signupValidators, validate, authController.signup);
router.post('/login', authLimiter, loginValidators, validate, authController.login);
router.post('/refresh', authLimiter, refreshValidators, validate, authController.refresh);
router.post('/logout', authController.logout);
router.get('/me', protect, authController.getMe);

module.exports = router;
