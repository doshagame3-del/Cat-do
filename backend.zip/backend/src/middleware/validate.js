'use strict';

const { validationResult } = require('express-validator');
const AppError = require('../utils/AppError');

/**
 * Runs after an express-validator chain and converts any accumulated
 * validation errors into a single 422 AppError with a structured list
 * of field-level issues.
 */
function validate(req, res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) {
    return next();
  }

  const details = result.array({ onlyFirstError: true }).map((err) => ({
    field: err.path,
    message: err.msg,
  }));

  const error = new AppError('Validation failed', 422, 'VALIDATION_ERROR');
  error.details = details;
  return next(error);
}

module.exports = validate;
