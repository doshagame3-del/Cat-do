'use strict';

const env = require('../config/env');
const logger = require('../utils/logger');

/**
 * Translates known Mongoose/JWT error shapes into operational AppError-like
 * responses so callers get a consistent, non-leaky error format.
 */
function normalizeError(err) {
  if (err.code === 11000) {
    return { statusCode: 409, code: 'DUPLICATE_KEY', message: 'Resource already exists' };
  }
  if (err.name === 'ValidationError') {
    return { statusCode: 422, code: 'VALIDATION_ERROR', message: 'Validation failed' };
  }
  if (err.name === 'CastError') {
    return { statusCode: 400, code: 'INVALID_ID', message: 'Invalid identifier supplied' };
  }
  return null;
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const normalized = err.isOperational ? null : normalizeError(err);

  const statusCode = err.statusCode || normalized?.statusCode || 500;
  const code = err.code && err.isOperational ? err.code : normalized?.code || 'INTERNAL_ERROR';
  const isKnown = err.isOperational || Boolean(normalized);

  if (!isKnown) {
    // Unexpected/programmer error: log full detail, never leak internals to the client.
    logger.error(`Unhandled error: ${err.message}`, { stack: err.stack });
  } else {
    logger.warn(`${code}: ${err.message}`);
  }

  const body = {
    status: 'error',
    code,
    message: isKnown ? err.message || normalized.message : 'Something went wrong. Please try again.',
  };

  if (err.details) {
    body.details = err.details;
  }

  if (!env.isProduction && !isKnown) {
    body.stack = err.stack;
  }

  res.status(statusCode).json(body);
}

module.exports = errorHandler;
