'use strict';

const User = require('../models/User');
const AppError = require('../utils/AppError');
const catchAsync = require('../utils/catchAsync');
const { verifyAccessToken } = require('../utils/tokens');

/**
 * Verifies the `Authorization: Bearer <token>` access token, loads the
 * corresponding user, and attaches it to req.user. Rejects with 401 on
 * any failure (missing header, malformed/expired token, deleted user).
 */
const protect = catchAsync(async (req, res, next) => {
  const authHeader = req.headers.authorization || '';
  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return next(new AppError('Authentication required', 401, 'NO_TOKEN'));
  }

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (err) {
    const code = err.name === 'TokenExpiredError' ? 'TOKEN_EXPIRED' : 'INVALID_TOKEN';
    return next(new AppError('Invalid or expired access token', 401, code));
  }

  if (payload.type !== 'access') {
    return next(new AppError('Invalid token type', 401, 'INVALID_TOKEN_TYPE'));
  }

  const user = await User.findById(payload.sub);
  if (!user) {
    return next(new AppError('User belonging to this token no longer exists', 401, 'USER_NOT_FOUND'));
  }

  req.user = user;
  next();
});

module.exports = protect;
