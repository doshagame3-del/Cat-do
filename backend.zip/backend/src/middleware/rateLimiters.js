'use strict';

const rateLimit = require('express-rate-limit');
const env = require('../config/env');

/**
 * Throttles brute-force attempts against signup/login. Keyed by IP;
 * in production behind a load balancer, ensure `app.set('trust proxy', 1)`
 * (already configured in app.js) so the real client IP is used.
 */
const authLimiter = rateLimit({
  windowMs: env.rateLimit.windowMs,
  max: env.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: 'error',
    code: 'RATE_LIMITED',
    message: 'Too many requests from this IP, please try again later.',
  },
});

module.exports = { authLimiter };
