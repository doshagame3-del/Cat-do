'use strict';

/**
 * Wraps an async Express handler so rejected promises are forwarded
 * to next(err) instead of crashing the process or hanging the request.
 */
function catchAsync(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = catchAsync;
