'use strict';

/**
 * Represents a known, expected error (bad input, auth failure, etc.)
 * as opposed to an unexpected bug. The global error handler uses
 * `isOperational` to decide whether to leak the message to the client.
 */
class AppError extends Error {
  constructor(message, statusCode, code = 'ERROR') {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
