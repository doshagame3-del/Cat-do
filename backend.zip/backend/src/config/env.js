'use strict';

require('dotenv').config();

/**
 * Required environment variables. The process will refuse to start
 * if any of these are missing, preventing silent misconfiguration
 * (e.g. running with a default/weak JWT secret in production).
 */
const REQUIRED_VARS = [
  'MONGO_URI',
  'JWT_ACCESS_SECRET',
  'JWT_REFRESH_SECRET',
];

function requireEnv(name, fallback) {
  const value = process.env[name] ?? fallback;
  if (value === undefined || value === '') {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

for (const key of REQUIRED_VARS) {
  if (!process.env[key]) {
    // eslint-disable-next-line no-console
    console.error(`[config] FATAL: missing required env var "${key}". See .env.example.`);
    process.exit(1);
  }
}

const env = Object.freeze({
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 5000,
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5500',

  mongoUri: requireEnv('MONGO_URI'),

  jwt: Object.freeze({
    accessSecret: requireEnv('JWT_ACCESS_SECRET'),
    refreshSecret: requireEnv('JWT_REFRESH_SECRET'),
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  }),

  rateLimit: Object.freeze({
    windowMs: parseInt(process.env.AUTH_RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
    max: parseInt(process.env.AUTH_RATE_LIMIT_MAX, 10) || 20,
  }),

  bcryptSaltRounds: parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 12,

  isProduction: process.env.NODE_ENV === 'production',
});

module.exports = env;
